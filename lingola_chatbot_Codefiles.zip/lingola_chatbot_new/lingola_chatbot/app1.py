from flask import Flask, render_template

app = Flask(__name__)

# Route to display the Fun & Games page
@app.route('/fun')
def fun_page():
    return render_template('games.html')

# Route for "Guess the Animal" Game (Temporary Placeholder)
@app.route('/guess_animal')
def guess_animal():
    return render_template('animal.html')

# Route for "Spelling Bee" Game (Temporary Placeholder)
@app.route('/spelling_bee')
def spelling_bee():
    return "<h1>Spelling Bee Game Page</h1>"

# Run the Flask app
if __name__ == '__main__':
    app.run(debug=True)
