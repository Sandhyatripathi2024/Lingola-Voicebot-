// ✅ Store the game rounds
const gameRounds = [
    {
        question: "Which animal's name starts with 'D'?",
        correctAnswer: "dog",
        options: ["dog", "cat", "lion"],
        images: ["dog.png", "cat.png", "lion.png"]
    },
    {
        question: "Which animal's name starts with 'E'?",
        correctAnswer: "elephant",
        options: ["elephant", "zebra", "horse"],
        images: ["elephant.png", "zebra.png", "horse.png"]
    }
];

let currentRound = 0; // Track current round
let answerSelected = false; // ✅ Prevent multiple attempts
let correctAnswersCount = 0; // ✅ Track correct answers

function checkAnswer(selectedAnimal) {
    if (answerSelected) return; // ✅ If already answered, do nothing
    answerSelected = true; // ✅ Mark that an answer was selected

    let resultMessage = document.getElementById("result-message");
    let nextButton = document.getElementById("next-round");

    // Check if the selected animal is correct
    if (selectedAnimal === gameRounds[currentRound].correctAnswer) {
        resultMessage.textContent = "🎉 Correct!";
        resultMessage.style.color = "green";
        correctAnswersCount++; // ✅ Increase correct answers count
    } else {
        resultMessage.textContent = "❌ Incorrect!";
        resultMessage.style.color = "red";
    }

    nextButton.style.display = "block"; // ✅ Show the next round button

    // ✅ Disable all images after selection
    document.getElementById("option1").style.pointerEvents = "none";
    document.getElementById("option2").style.pointerEvents = "none";
    document.getElementById("option3").style.pointerEvents = "none";
}

// ✅ Move to the Next Round
function nextRound() {
    currentRound++;
    answerSelected = false; // ✅ Allow answering in the next round

    if (currentRound < gameRounds.length) {
        // Update the question
        document.getElementById("question").textContent = gameRounds[currentRound].question;

        // Update the images and options dynamically
        document.getElementById("option1").src = `static/${gameRounds[currentRound].images[0]}`;
        document.getElementById("option1").setAttribute("onclick", `checkAnswer('${gameRounds[currentRound].options[0]}')`);

        document.getElementById("option2").src = `static/${gameRounds[currentRound].images[1]}`;
        document.getElementById("option2").setAttribute("onclick", `checkAnswer('${gameRounds[currentRound].options[1]}')`);

        document.getElementById("option3").src = `static/${gameRounds[currentRound].images[2]}`;
        document.getElementById("option3").setAttribute("onclick", `checkAnswer('${gameRounds[currentRound].options[2]}')`);

        // ✅ Re-enable clicking on images
        document.getElementById("option1").style.pointerEvents = "auto";
        document.getElementById("option2").style.pointerEvents = "auto";
        document.getElementById("option3").style.pointerEvents = "auto";

        // Hide result message & next button
        document.getElementById("result-message").textContent = "";
        document.getElementById("next-round").style.display = "none";
    } else {
        // ✅ Game Over Message with Correct Answers Count
        document.getElementById("question").textContent = `🎉 Well done! You completed the game!`;
        document.querySelector(".animal-container").style.display = "none"; // Hide animal choices
        document.getElementById("next-round").style.display = "none"; // Hide next button

        // ✅ Show total correct answers
        let finalMessage = document.getElementById("result-message");
        let mascotImage = document.getElementById("mascot-image");

        if (correctAnswersCount === 2) {
            finalMessage.textContent = `🏆 Amazing! You got ${correctAnswersCount}/2 correct!`;
            finalMessage.style.color = "green";
            mascotImage.src = "static/mascot_gold.png"; // ✅ Mascot with Gold Badge
        } else if (correctAnswersCount === 1) {
            finalMessage.textContent = `🥈 Great job! You got ${correctAnswersCount}/2 correct!`;
            finalMessage.style.color = "green";
            mascotImage.src = "static/mascot_silver.png"; // ✅ Mascot with Silver Badge
        } else {
            finalMessage.textContent = `😢 Better luck next time!`;
            finalMessage.style.color = "red";
            mascotImage.src = "static/mascot_better_luck.png"; // ✅ Mascot with "Better Luck" board
        }

       // ✅ Ensure mascot stays at bottom without pushing anything up
       mascotImage.style.display = "block"; 
       resizeMascot();

       // ===== New Code: Send game result to the backend =====
       const finalResult = `${correctAnswersCount}/${gameRounds.length}`;
       fetch('/store_result', {
           method: 'POST',
           headers: {
               'Content-Type': 'application/json'
           },
           body: JSON.stringify({ result: finalResult })
       })
       .then(response => response.json())
       .then(data => {
           console.log("Store result response:", data);
       })
       .catch(error => {
           console.error("Error storing result:", error);
       });
       // =====================================================
    }
}
// ✅ Resize mascot dynamically based on screen size
function resizeMascot() {
    let mascotImage = document.getElementById("mascot-image");
    if (!mascotImage) return;

    let screenWidth = window.innerWidth;

    if (screenWidth > 1024) {
        mascotImage.style.width = "200px"; 
    } else if (screenWidth > 768) {
        mascotImage.style.width = "180px"; 
    } else if (screenWidth > 480) {
        mascotImage.style.width = "150px"; 
    } else {
        mascotImage.style.width = "120px"; 
    }
}

// ✅ Run function on page load & window resize
window.onload = resizeMascot;
window.onresize = resizeMascot;

function goToHome() {
    window.location.href = "/home";  // or "/"
}
