let startBtn = document.getElementById("start-recording");
let stopBtn = document.getElementById("stop-recording");
let statusElem = document.getElementById("status");
let responseAudio = document.getElementById("response-audio");
let finishBtn = document.getElementById("finish-session");

let mediaRecorder;
let audioChunks = [];
let sessionStartTime = null; // Will store the session start timestamp

// 🎤 Start Recording
startBtn.addEventListener("click", async () => {
  try {
    // Request microphone access
    let stream = await navigator.mediaDevices.getUserMedia({ audio: true });

    // Check if browser supports MediaRecorder
    if (!MediaRecorder) {
      alert("Your browser does not support audio recording.");
      return;
    }

    mediaRecorder = new MediaRecorder(stream, { mimeType: "audio/webm" });
    audioChunks = [];

    mediaRecorder.ondataavailable = event => {
      if (event.data.size > 0) {
        audioChunks.push(event.data);
      }
    };

    // Set session start time when recording begins
    sessionStartTime = Date.now();

    mediaRecorder.start();
    statusElem.textContent = "Recording...";
    startBtn.disabled = true;
    stopBtn.disabled = false;
  } catch (error) {
    alert("Microphone access denied or unavailable.");
    console.error("❌ ERROR: ", error);
  }
});

// ⏹️ Stop Recording
stopBtn.addEventListener("click", async () => {
  if (!mediaRecorder || mediaRecorder.state !== "recording") {
    console.error("❌ ERROR: No active recording to stop.");
    return;
  }

  mediaRecorder.stop();
  stopBtn.disabled = true;
  startBtn.disabled = false;
  statusElem.textContent = "Processing audio...";

  mediaRecorder.onstop = async () => {
    if (audioChunks.length === 0) {
      console.error("❌ ERROR: No audio recorded.");
      statusElem.textContent = "Error: No audio detected.";
      return;
    }

    // Create a Blob from the recorded audio
    let audioBlob = new Blob(audioChunks, { type: "audio/webm" });
    console.log(`📂 Recorded Audio Size: ${audioBlob.size} bytes`);

    if (audioBlob.size < 1000) {
      console.error("❌ ERROR: Audio file too small. Try speaking louder.");
      statusElem.textContent = "Error: Audio file too small.";
      return;
    }

    let formData = new FormData();
    formData.append("audio", audioBlob, "input.webm");

    console.log("📡 Sending audio to backend...");

    try {
      // POST to /process_audio on the same server
      let response = await fetch("/process_audio", {
        method: "POST",
        body: formData
      });

      if (!response.ok) {
        throw new Error("Server error, failed to process audio.");
      }

      // The backend returns a WAV audio file
      let blob = await response.blob();
      let audioURL = URL.createObjectURL(blob);
      responseAudio.src = audioURL;
      responseAudio.play();
      statusElem.textContent = "Response received!";
      startBtn.disabled = false;
    } catch (error) {
      console.error("❌ ERROR:", error);
      statusElem.textContent = "Error processing request.";
      startBtn.disabled = false;
      
    }

    audioChunks = [];
  };
});

// Finish Session Endpoint
finishBtn.addEventListener("click", () => {
  if (sessionStartTime === null) {
    console.error("Session start time not recorded.");
    return;
  }

  // Calculate duration in seconds from the start of recording until finish button click
  let duration = (Date.now() - sessionStartTime) / 1000;
  console.log("Session Duration (s):", duration);

  // Send the duration to the backend finish endpoint
  fetch("/finish", {
    method: "POST",
    headers: {
      "Content-Type": "application/json"
    },
    body: JSON.stringify({ duration: duration })
  })
    .then(response => response.json())
    .then(data => {
      console.log("Finish session response:", data);
      if (data.success) {
        // Optionally redirect to a results or summary page:
        window.location.href = '/fun';
      } else {
        console.error("Error finishing session:", data);
      }
    })
    .catch(err => console.error("Error finishing session:", err));
});

// NEW CODE: Pulse Mascot When Audio is Playing
document.addEventListener("DOMContentLoaded", () => {
  const mascotContainer = document.getElementById("mascotContainer");
  if (!mascotContainer) return;

  responseAudio.addEventListener("play", () => {
    mascotContainer.classList.add("responding");
  });

  responseAudio.addEventListener("pause", () => {
    mascotContainer.classList.remove("responding");
  });

  responseAudio.addEventListener("ended", () => {
    mascotContainer.classList.remove("responding");
  });
});