import io
import os
import subprocess
import mysql.connector
import tempfile
from flask import Flask, request, send_file, jsonify, render_template, redirect, url_for
from google.cloud import speech, texttospeech
from google.oauth2 import service_account

# ----------------------------------------------------
# 1. MySQL Database Connection
# ----------------------------------------------------
DB_CONFIG = {
    "host": "localhost",
    "user": "admin",
    "password": "adminpassword",
    "database": "voicebot_db"
}

def get_db_connection():
    return mysql.connector.connect(**DB_CONFIG)

# ----------------------------------------------------
# 2. Load Credentials
# ----------------------------------------------------
STT_CREDS_PATH = r"C:\Users\Sandhya\OneDrive\Desktop\Speech to Text JSON\horizontal-ring-443809-k3-7e6966d480d8.json"
TTS_CREDS_PATH = r"C:\Users\Sandhya\OneDrive\Desktop\Text to Speech JSON\horizontal-ring-443809-k3-f673f003030e.json"

stt_credentials = service_account.Credentials.from_service_account_file(STT_CREDS_PATH)
tts_credentials = texttospeech.TextToSpeechClient(credentials=service_account.Credentials.from_service_account_file(TTS_CREDS_PATH))

stt_client = speech.SpeechClient(credentials=stt_credentials)
tts_client = tts_credentials

# ----------------------------------------------------
# 3. Flask Setup
# ----------------------------------------------------
app = Flask(__name__)

# ----------------------------------------------------
# 4. Home Page: Collect User Name and Age
# ----------------------------------------------------
@app.route('/home', methods=['GET', 'POST'])
def home():
    if request.method == 'POST':
        name = request.form.get('name')
        age = request.form.get('age')
        # Create 'users' table if it doesn't exist and store user info
        conn = get_db_connection()
        cursor = conn.cursor()
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS users (
                id INT AUTO_INCREMENT PRIMARY KEY,
                name VARCHAR(255) NOT NULL,
                age INT NOT NULL,
                start_datetime TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)
        conn.commit()
        cursor.execute("INSERT INTO users (name, age) VALUES (%s, %s)", (name, age))
        conn.commit()
        cursor.close()
        conn.close()
        return redirect(url_for('index',name=name))
    return render_template('home.html')

        
# ----------------------------------------------------
# 5. Voice Bot Page (Existing)
# ----------------------------------------------------
@app.route('/')
def index():
     # Grab 'name' from the URL query string, default to 'Guest' if missing
    user_name = request.args.get('name', 'Guest')
    # Pass 'name' to the template
    return render_template('index.html', name=user_name)
    

# ----------------------------------------------------
# 7. /process_audio Endpoint (Existing)
# ----------------------------------------------------
@app.route('/process_audio', methods=['POST'])
def process_audio():
    if 'audio' not in request.files:
        return jsonify({"error": "No audio file provided"}), 400

    file = request.files['audio']
    webm_data = file.read()

    wav_data = convert_webm_to_wav(webm_data)
    transcript = speech_to_text(wav_data)
    if not transcript:
        return jsonify({"error": "No speech detected or could not transcribe."}), 400

    # (1) Append child's transcript
    append_conversation_as_file("Child", transcript)

    # Get LLaMA response
    llama_resp = get_llama_response(transcript)

    # (2) Append Lingola's text
    append_conversation_as_file("Lingola", llama_resp)

    # Convert LLaMA text response to speech
    tts_audio = text_to_speech(llama_resp, language_code="en-US")

    return send_file(
        io.BytesIO(tts_audio),
        mimetype='audio/wav',
        as_attachment=False,
        download_name='response.wav'
    )

# ----------------------------------------------------
# 8. Helper: Convert .webm to .wav (Existing)
# ----------------------------------------------------
def convert_webm_to_wav(webm_bytes):
    with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as temp_in:
        temp_in.write(webm_bytes)
        temp_in.flush()
        in_path = temp_in.name

    with tempfile.NamedTemporaryFile(suffix=".wav", delete=False) as temp_out:
        out_path = temp_out.name

    try:
        command = ["ffmpeg", "-y", "-i", in_path, "-ar", "16000", out_path]
        result = subprocess.run(command, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True, encoding="utf-8", errors="replace")
        print("FFmpeg Error:", result.stderr)
        with open(out_path, "rb") as f:
            wav_data = f.read()
    finally:
        os.remove(in_path)
        os.remove(out_path)

    return wav_data

# ----------------------------------------------------
# 9. Existing Functions: STT, TTS, LLaMA
# ----------------------------------------------------
def speech_to_text(wav_bytes, sample_rate=16000):
    audio = speech.RecognitionAudio(content=wav_bytes)
    config = speech.RecognitionConfig(
        encoding=speech.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=sample_rate,
        language_code="en-US",
    )
    response = stt_client.recognize(config=config, audio=audio)
    if not response.results:
        return ""
    return response.results[0].alternatives[0].transcript

def text_to_speech(text, language_code="en-US"):
    synthesis_input = texttospeech.SynthesisInput(text=text)
    voice = texttospeech.VoiceSelectionParams(
        language_code=language_code,
        name="en-US-Wavenet-C",
        ssml_gender=texttospeech.SsmlVoiceGender.FEMALE
    )
    audio_config = texttospeech.AudioConfig(
        pitch=9.0,
        audio_encoding=texttospeech.AudioEncoding.LINEAR16
    )
    response = tts_client.synthesize_speech(
        input=synthesis_input,
        voice=voice,
        audio_config=audio_config
    )
    return response.audio_content

def get_llama_response(user_input):
    prompt = (
        "You are Lingola, a female English teacher helping kids aged 6–12 learn English in a friendly, child-appropriate manner."
        "You always correct mistakes gently and praise their efforts."

        "TEACHING ALPHABETS:"
        "1. List A–Z once, no repeats."
        "2. Ask the child to say them out loud.wait for the child response."
        "3. Ask the child,'how many alphabets are there in english?'"
        "4. If child says '26' letters, respond 'Yes, 26 is correct!'"
        "5. If child says other than 26 respond 'No, 26 is correct answer.'"
        "6. Then ask: 'Do you want to learn anything else?'" 
            "- If 'Yes,' respond to their new request."
            "- If the child says 'No', then say: 'Great job today! You did really well. I will see you next time!'\n"

        "TEACHING NUMBERS (1–10):"
        "1. List 1–10 one time, without repeating each number (e.g., “one, two, three…”)"
        "2. Ask the child to repeat them out loud and wait for the child response. "
        "3. Ask the child,'what number comes after number 5?'"
        "4. If child says number '6' , respond 'Yes, 6 is correct!'"
        "5. If child says other than 6 respond 'No, 6 is correct answer.'"
        "6. Then ask: 'Do you want to learn anything else?'" 
            "- If 'Yes,' respond to their new request."
            "- If the child says 'No', then say: 'Great job today! You did really well. I will see you next time!'\n"
        
        "TEACHING ANIMAL VOCABULARY:"

        "1.Introduce the animal names by saying, 'Let's talk about animals: Dog, Cat, and Horse.'"
        "2.Ask the child to repeat the names out loud: 'Can you say Dog, Cat, and Horse with me?'"
        "3.Ask the child, 'Which animal is your favorite?'"
        "4.If the child names an animal respond positively"
        "5.If the child doesn't provide a clear answer, encourage the child to try again"
        "6. Then ask: 'Do you want to learn anything else?'"
            "- If 'Yes,' respond to their new request."
            "- If the child says 'No', then say: 'Great job today! You did really well. I will see you next time!'\n"

        "TEACHING PRONUNCIATION"   
        "1.Tell 'Lets learn S sound Six slippery snails slid slowly.Now, can you repeat that two times in a row? Try to say each word clearly! '"
        "2.wait for child response. gently correct if there is minstake in pronunciation" 
        "3. Then ask: 'Do you want to learn anything else?'" 
            "- If 'Yes,' respond to their new request."
            "- If the child says 'No', then say: 'Great job today! You did really well. I will see you next time!'" 
            
        "Now, based on all these instructions, respond to the child in a friendly, child-appropriate manner. in the end do not summarize about any topics.\n\n"
        f"Student says: {user_input}\n\n"
        "Teacher (in English):"  

    )

    try:
        result = subprocess.run(
            ["ollama", "run", "llama3.1"],
            input=prompt,
            capture_output=True,
            text=True
        )
        if result.returncode != 0:
            return "Sorry, I couldn't understand. Please try again."
        return result.stdout.strip()
    except Exception as e:
        return f"Error running Ollama: {e}"

# ----------------------------------------------------
# 10. Finish Session Endpoint (Updated)
# ----------------------------------------------------
@app.route('/finish', methods=['POST'])
def finish_session():
    data = request.get_json()
    duration = data.get("duration")
    print("Finish session endpoint hit, duration:", duration)

    conn = get_db_connection()
    cursor = conn.cursor()

    # 1) Add 'duration' column if not found
    cursor.execute("SHOW COLUMNS FROM users LIKE 'duration'")
    result = cursor.fetchone()
    if not result:
        cursor.execute("ALTER TABLE users ADD COLUMN duration FLOAT")
        conn.commit()

    # 2) Update the last inserted user row with new duration
    cursor.execute("UPDATE users SET duration = %s ORDER BY id DESC LIMIT 1", (duration,))
    conn.commit()

    # 3) Ensure end_date_time column
    cursor.execute("SHOW COLUMNS FROM users LIKE 'end_date_time'")
    result_end_time = cursor.fetchone()
    if not result_end_time:
        cursor.execute("ALTER TABLE users ADD COLUMN end_date_time DATETIME")
        conn.commit()

    # Update last inserted row with the current timestamp (NOW())
    cursor.execute("UPDATE users SET end_date_time = NOW() ORDER BY id DESC LIMIT 1")
    conn.commit()

    # 4) Calculate number_of_turns
    cursor.execute("SELECT id FROM users ORDER BY id DESC LIMIT 1")
    user_row = cursor.fetchone()
    if user_row:
        last_user_id = user_row[0]
        cursor.execute("SELECT user_chat FROM Chat WHERE id = %s", (last_user_id,))
        chat_row = cursor.fetchone()
        if chat_row:
            user_chat = chat_row[0] or ""
            lines = user_chat.strip().split("\n")

            turns = 0
            for line in lines:
                if line.startswith("Child says:"):
                    turns += 1

            cursor.execute("""
                UPDATE users
                SET number_of_turns = %s
                WHERE id = %s
            """, (turns, last_user_id))
            conn.commit()

            # 5) Ensure 'topics_covered' column exists
            cursor.execute("SHOW COLUMNS FROM users LIKE 'topics_covered'")
            result_topic = cursor.fetchone()
            if not result_topic:
                cursor.execute("""
                    ALTER TABLE users
                    ADD COLUMN topics_covered VARCHAR(255)
                    AFTER end_date_time
                """)
                conn.commit()

            # Simple approach: search for keywords in conversation
            topic_keywords = {
                "alphabet": ["alphabet", "letters", "abc"],
                "numbers": ["numbers", "1 to 10", "counting", "one two three"],
                "vocabulary": ["vocabulary", "colors", "fruits", "food", "country", "continent"],
                "animal vocabulary": [ "animals", "cat", "dog", "horse"],
                "pronunciation": [ "tongue twister", "six slippery snails slid slowly"]
            }

            found_topics = set()
            lower_convo = user_chat.lower()

            # Check each topic's keywords in the conversation
            for topic, keywords in topic_keywords.items():
                for kw in keywords:
                    if kw in lower_convo:
                        found_topics.add(topic)
                        break  # no need to check more keywords for this topic

            topics_str = ", ".join(found_topics) if found_topics else "none"

            cursor.execute("""
                UPDATE users
                SET topics_covered = %s
                WHERE id = %s
            """, (topics_str, last_user_id))
            conn.commit()

            cursor.close()
            conn.close()
            
    return jsonify({"success": True}) 

# ----------------------------------------------------
# 11. Append Conversation as File (REMOVED FILE LOGIC)
# ----------------------------------------------------
def append_conversation_as_file(speaker, message):
    """
    Directly store conversation text in the Chat table (1:1 with Users).
    We retrieve the last inserted user, then either insert or update
    Chat.user_chat with the new line: "speaker says: message"
    """
    line_to_append = f"{speaker} says: {message}\n"

    conn = get_db_connection()
    cursor = conn.cursor()

    # Ensure Chat table exists
    cursor.execute("""
        CREATE TABLE IF NOT EXISTS Chat (
            id INT PRIMARY KEY,
            user_chat LONGTEXT,
            CONSTRAINT fk_chat_users
                FOREIGN KEY (id) REFERENCES users(id)
                ON DELETE CASCADE
                ON UPDATE CASCADE
        )
    """)
    conn.commit()

    # Find the last inserted user
    cursor.execute("SELECT id FROM users ORDER BY id DESC LIMIT 1")
    row = cursor.fetchone()
    if not row:
        cursor.close()
        conn.close()
        return
    user_id = row[0]

    # Check existing conversation text
    cursor.execute("SELECT user_chat FROM Chat WHERE id = %s", (user_id,))
    existing_row = cursor.fetchone()

    if existing_row is None:
        cursor.execute("INSERT INTO Chat (id, user_chat) VALUES (%s, %s)", (user_id, line_to_append))
    else:
        existing_text = existing_row[0] or ''
        new_text = existing_text + line_to_append
        cursor.execute("UPDATE Chat SET user_chat = %s WHERE id = %s", (new_text, user_id))

    conn.commit()
    cursor.close()
    conn.close()

# @app.route('/stats')
# def stats():
#     # Connect to DB
#     conn = get_db_connection()
#     cursor = conn.cursor()
    
#     # Query only the columns you want
#     cursor.execute("SELECT name,age,topics_covered, start_date_time,duration, number_of_turns FROM users")
#     rows = cursor.fetchall()
    
#     cursor.close()
#     conn.close()
    
#     # Render a new template called 'stats.html', passing the query results
#     return render_template('stats.html', rows=rows) 

# Hardcoded teacher credentials (for prototype)
TEACHER_CREDENTIALS = {
    "teacher@lingola.com": "password123"
}
 
@app.route('/teacher_login', methods=['GET', 'POST'])
def teacher_login():
    error = None
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
 
        # Check if email and password match
        if email in TEACHER_CREDENTIALS and TEACHER_CREDENTIALS[email] == password:
            return redirect(url_for('teacher_dashboard'))  # ✅ Redirect to dashboard
        else:
            error = "Invalid Email or Password. Try Again!"
 
    return render_template('teacher.html', error=error)
 
@app.route('/teacher_dashboard')
def teacher_dashboard():
    conn = get_db_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT name, age, topics_covered, start_date_time, duration, number_of_turns,game_result FROM users")
    rows = cursor.fetchall()
    cursor.close()
    conn.close()
    return render_template('stats.html', rows=rows)

@app.route('/fun')
def fun_page():
    return render_template('games.html')

@app.route('/guess_animal')
def guess_animal():
    return render_template('animal.html')

@app.route('/spelling_bee')
def spelling_bee():
    # Just a placeholder for now
    return "<h1>Spelling Bee Game Page</h1>"

@app.route('/store_result', methods=['POST'])
def store_result():
    data = request.get_json()
    result_value = data.get("result")
    if not result_value:
        return jsonify({"error": "No result provided"}), 400

    conn = get_db_connection()
    cursor = conn.cursor()
    
    # Ensure the "Game_Result" column exists in the users table
    cursor.execute("SHOW COLUMNS FROM users LIKE 'Game_Result'")
    game_result_col = cursor.fetchone()
    if not game_result_col:
        cursor.execute("ALTER TABLE users ADD COLUMN Game_Result VARCHAR(10)")
        conn.commit()

    # Retrieve the last inserted user (assuming that's the user to update)
    cursor.execute("SELECT id FROM users ORDER BY id DESC LIMIT 1")
    user_row = cursor.fetchone()
    if not user_row:
        cursor.close()
        conn.close()
        return jsonify({"error": "No user found"}), 404

    last_user_id = user_row[0]
    # Update the user's Game_Result column with the score
    cursor.execute("UPDATE users SET Game_Result = %s WHERE id = %s", (result_value, last_user_id))
    conn.commit()

    cursor.close()
    conn.close()
    return jsonify({"success": True, "message": "Game result stored."})

    
if __name__ == '__main__':
    app.run(debug=True, port=5000)
    
